let config = {
	serverUrl: 'http://tessellate.elasticbeanstalk.com',
	tokenName: 'tessellate',
	tokenDataName: 'tessellate-tokenData',
	tokenUserDataName: 'tessellate-currentUser'
};
export default config;
