### [0.0.1](https://github.com/kypertech/matter-library/releases/tag/v0.0.1)

- The first release